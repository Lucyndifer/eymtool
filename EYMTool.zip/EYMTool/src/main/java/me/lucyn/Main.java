package me.lucyn;

import com.nicehash.connect.Api;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.LocalTime;


public class Main {



    private Log log = LogFactory.getLog(Main.class);

    private static final String URL_ROOT   = "https://api2.nicehash.com";
    private static final String ORG_ID     = "75a98743-da27-4c19-95e5-5dfdeb2b3bd3"; //get it here: https://test.nicehash.com/my/settings/keys or https://new.nicehash.com/my/settings/keys
    private static final String API_KEY    = "de48f614-a2dc-4240-ace2-672626dccab3";
    private static final String API_SECRET = "78dab88b-68ee-4bf3-986f-7085ec8e3d24bfcac59b-b33a-4eb5-9b34-6b6bbebea6fd";


    public static void main(String[] args) throws IOException {

        Api api = new Api(URL_ROOT, ORG_ID, API_KEY, API_SECRET);

        BufferedReader in = new BufferedReader(new FileReader("src/main/resources/data.txt"));

        String results = api.get("/main/api/v2/mining/rigs/activeWorkers", true, String.valueOf(System.currentTimeMillis()));

        int[] times = new int[8];

        String miner1 = "Allen";
        String miner2 = "Julian";
        String miner3 = "paulino";
        String miner4 = "Sammy";
        String miner5 = "fluffy";
        String miner6 = "lucyn";
        String miner7 = "nibples";
        String miner8 = "IceFox";


        int r;
        int i = 0;
        String currentLine;

        while ((currentLine = in.readLine()) != null) {
            times[i] = Integer.parseInt(currentLine);
            System.out.println(currentLine);

            i++;
        }
        in.close();

        if (results.contains(miner1)) {
            times[0] += 1;
        }
        if (results.contains(miner2)) {
            times[1] += 1;
        }
        if (results.contains(miner3)) {
            times[2] += 1;
        }
        if (results.contains(miner4)) {
            times[3] += 1;
        }
        if (results.contains(miner5)) {
            times[4] += 1;
        }
        if (results.contains(miner6)) {
            times[5] += 1;
        }
        if (results.contains(miner7)) {
            times[6] += 1;
        }
        if (results.contains(miner8)) {
            times[7] += 1;
        }

        FileWriter out = new FileWriter("src/main/resources/data.txt");

        for (int f : times) {
            out.write(String.valueOf(f) + "\n");
        }
        out.close();



        LocalTime now = LocalTime.now();

        if (now.getHour() == 0 && (now.getMinute() >= 0 && now.getMinute() < 5)) {
            FileWriter out2 = new FileWriter("src/main/resources/data.txt");
            ///////////////////////////////////////////////
            // CONFIG
            String tokenWebhook = "https://discord.com/api/webhooks/945067414532538388/TR0sTODigZT3elvJOKIuadYY8KuujwJLCj2Faqkb3rEzOUubMbOtLPfYUevyBRH5GVZr";
            String title = "NH Hours";
            String message = miner1 + ": " + (times[0] / 12) + "\\n" +
                    miner2 + ": " + (times[1] / 12) + "\\n" +
                    miner3 + ": " + (times[2] / 12) + "\\n" +
                    miner4 + ": " + (times[3] / 12) + "\\n" +
                    miner5 + ": " + (times[4] / 12) + "\\n" +
                    miner6 + ": " + (times[5] / 12) + "\\n" +
                    miner7 + ": " + (times[6] / 12) + "\\n" +
                    miner8 + ": " + (times[7] / 12);

            for (int f : times) {
                out2.write("0" + "\n");
            }


            ///////////////////////////////////////////////
            String jsonBrut = "";
            jsonBrut += "{\"embeds\": [{"
                    + "\"title\": \"" + title + "\","
                    + "\"description\": \"" + message + "\","
                    + "\"color\": 15258703"
                    + "}]}";
            try {
                URL url = new URL(tokenWebhook);
                HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
                con.addRequestProperty("Content-Type", "application/json");
                con.addRequestProperty("User-Agent", "Java-DiscordWebhook-BY-Gelox_");
                con.setDoOutput(true);
                con.setRequestMethod("POST");
                OutputStream stream = con.getOutputStream();
                stream.write(jsonBrut.getBytes());
                stream.flush();
                stream.close();
                con.getInputStream().close();
                con.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }

            out2.close();
        }

    }
}

